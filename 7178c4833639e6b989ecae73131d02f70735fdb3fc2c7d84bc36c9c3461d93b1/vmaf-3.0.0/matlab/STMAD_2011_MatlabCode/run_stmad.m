function run_stmad(ref_filename, dis_filename, width, height)

path(path,'./STMAD_2011_MatlabCode');

calcSTMADScore(ref_filename, dis_filename, width, height);

% dmos_score = rred2dmos(strred_score)

end
